from pasajero import Pasajero

class ListaPasajerosManual:

    def __init__(self, capacidad=20):
        self.datos = [None] * capacidad
        self.cantidad = 0
        self.capacidad = capacidad

    def añadir(self, pasajero):
        if self.cantidad >= self.capacidad:
            return False

        if self.buscar(pasajero.cedula) != -1:
            return False

        self.datos[self.cantidad] = pasajero
        self.cantidad += 1
        return True

    def listar(self):
        if self.cantidad == 0:
            print("Lista vacía")
            return

        for i in range(self.cantidad):
            print(f"[{i}] {self.datos[i]}")

    def longitud(self):
        return self.cantidad

    def insertar(self, posicion, pasajero):
        if posicion < 0 or posicion > self.cantidad:
            return False

        if self.cantidad >= self.capacidad:
            return False

        if self.buscar(pasajero.cedula) != -1:
            return False

        i = self.cantidad

        while i > posicion:
            self.datos[i] = self.datos[i - 1]
            i -= 1

        self.datos[posicion] = pasajero
        self.cantidad += 1
        return True

    def buscar(self, cedula):
        i = 0

        while i < self.cantidad:
            if self.datos[i].cedula == cedula:
                return i
            i += 1

        return -1

    def buscar_binaria(self, cedula):
        izquierda = 0
        derecha = self.cantidad - 1

        while izquierda <= derecha:
            medio = (izquierda + derecha) // 2

            if self.datos[medio].cedula == cedula:
                return medio

            if self.datos[medio].cedula < cedula:
                izquierda = medio + 1
            else:
                derecha = medio - 1

        return -1

    def modificar(self, cedula, nuevo_nombre, nueva_edad):
        posicion = self.buscar(cedula)

        if posicion == -1:
            return False

        self.datos[posicion].nombre = nuevo_nombre
        self.datos[posicion].edad = nueva_edad
        return True

    def eliminar_por_posicion(self, posicion):
        if posicion < 0 or posicion >= self.cantidad:
            return None

        eliminado = self.datos[posicion]
        i = posicion

        while i < self.cantidad - 1:
            self.datos[i] = self.datos[i + 1]
            i += 1

        self.cantidad -= 1
        self.datos[self.cantidad] = None

        return eliminado

    def eliminar_por_valor(self, cedula):
        posicion = self.buscar(cedula)

        if posicion == -1:
            return False

        self.eliminar_por_posicion(posicion)
        return True

    def ordenar_asc(self):
        for i in range(self.cantidad - 1):
            for j in range(self.cantidad - 1 - i):
                if self.datos[j].cedula > self.datos[j + 1].cedula:
                    aux = self.datos[j]
                    self.datos[j] = self.datos[j + 1]
                    self.datos[j + 1] = aux

    def ordenar_desc(self):
        for i in range(self.cantidad - 1):
            for j in range(self.cantidad - 1 - i):
                if self.datos[j].cedula < self.datos[j + 1].cedula:
                    aux = self.datos[j]
                    self.datos[j] = self.datos[j + 1]
                    self.datos[j + 1] = aux

    def reversar(self):
        izquierda = 0
        derecha = self.cantidad - 1

        while izquierda < derecha:
            aux = self.datos[izquierda]
            self.datos[izquierda] = self.datos[derecha]
            self.datos[derecha] = aux

            izquierda += 1
            derecha -= 1

    def copiar(self):
        nueva_lista = ListaPasajerosManual(self.capacidad)

        for i in range(self.cantidad):
            nueva_lista.añadir(self.datos[i])

        return nueva_lista

    def filtrar_mayores_de_edad(self):
        nueva_lista = ListaPasajerosManual(self.capacidad)

        for i in range(self.cantidad):
            if self.datos[i].es_mayor_de_edad():
                nueva_lista.añadir(self.datos[i])

        return nueva_lista

    def nombres_en_mayusculas(self):
        resultado = [None] * self.cantidad

        for i in range(self.cantidad):
            resultado[i] = self.datos[i].nombre.upper()

        return resultado