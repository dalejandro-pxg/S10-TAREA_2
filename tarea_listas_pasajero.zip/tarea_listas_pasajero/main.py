from pasajero import Pasajero
from lista_manual import ListaPasajerosManual
from lista_python import ListaPasajerosPython
from ejercicios import menu_ejercicios

lista1 = ListaPasajerosManual(20)
lista2 = ListaPasajerosPython()

def leer_entero(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print("Error: debe ingresar un número entero.")

def leer_pasajero():
    nombre = input("Nombre: ").strip()
    cedula = input("Cédula: ").strip()
    edad = leer_entero("Edad: ")

    if nombre == "" or cedula == "" or edad < 0:
        print("Datos inválidos.")
        return None

    return Pasajero(nombre, cedula, edad)

def cargar_datos(lista):
    datos = [
        Pasajero("Diana", "0923456789", 22),
        Pasajero("Ana", "0912345678", 28),
        Pasajero("Luis", "0987654321", 35),
        Pasajero("Beto", "0934567890", 16),
        Pasajero("Elena", "0901234567", 41)
    ]

    for pasajero in datos:
        lista.añadir(pasajero)

    print("Datos de prueba cargados.")

def menu_lista(lista, titulo):
    while True:
        print(f"\n===== {titulo} =====")
        print("1. Añadir pasajero")
        print("2. Listar pasajeros")
        print("3. Insertar pasajero")
        print("4. Buscar pasajero")
        print("5. Buscar pasajero (binaria)")
        print("6. Modificar pasajero")
        print("7. Eliminar por posición")
        print("8. Eliminar por cédula")
        print("9. Ordenar ascendente")
        print("10. Ordenar descendente")
        print("11. Reversar")
        print("12. Copiar lista")
        print("13. Mostrar longitud")
        print("14. Filtrar mayores de edad")
        print("15. Mostrar nombres en mayúsculas")
        print("C. Cargar datos de prueba")
        print("0. Volver")

        opcion = input("Seleccione una opción: ").strip().upper()

        if opcion == "1":
            pasajero = leer_pasajero()
            if pasajero is not None:
                if lista.añadir(pasajero):
                    print("Pasajero añadido.")
                else:
                    print("No se pudo añadir. Revise la capacidad o la cédula repetida.")

        elif opcion == "2":
            lista.listar()

        elif opcion == "3":
            posicion = leer_entero("Posición: ")
            pasajero = leer_pasajero()

            if pasajero is not None:
                if lista.insertar(posicion, pasajero):
                    print("Pasajero insertado.")
                else:
                    print("No se pudo insertar.")

        elif opcion == "4":
            cedula = input("Cédula que desea buscar: ").strip()
            posicion = lista.buscar(cedula)

            if posicion == -1:
                print("Pasajero no encontrado.")
            else:
                print("Encontrado en posición:", posicion)

        elif opcion == "5":
            cedula = input("Cédula que desea buscar: ").strip()
            lista.ordenar_asc()
            posicion = lista.buscar_binaria(cedula)

            if posicion == -1:
                print("Pasajero no encontrado.")
            else:
                print("Encontrado en posición:", posicion)

        elif opcion == "6":
            cedula = input("Cédula del pasajero: ").strip()
            nombre = input("Nuevo nombre: ").strip()
            edad = leer_entero("Nueva edad: ")

            if edad < 0 or nombre == "":
                print("Datos inválidos.")
            elif lista.modificar(cedula, nombre, edad):
                print("Pasajero modificado.")
            else:
                print("Pasajero no encontrado.")

        elif opcion == "7":
            posicion = leer_entero("Posición que desea eliminar: ")
            eliminado = lista.eliminar_por_posicion(posicion)

            if eliminado is None:
                print("Posición inválida.")
            else:
                print("Eliminado:", eliminado)

        elif opcion == "8":
            cedula = input("Cédula que desea eliminar: ").strip()

            if lista.eliminar_por_valor(cedula):
                print("Pasajero eliminado.")
            else:
                print("Pasajero no encontrado.")

        elif opcion == "9":
            lista.ordenar_asc()
            print("Lista ordenada de forma ascendente.")

        elif opcion == "10":
            lista.ordenar_desc()
            print("Lista ordenada de forma descendente.")

        elif opcion == "11":
            lista.reversar()
            print("Lista invertida.")

        elif opcion == "12":
            copia = lista.copiar()
            print("Copia de la lista:")
            copia.listar()

        elif opcion == "13":
            print("Cantidad de pasajeros:", lista.longitud())

        elif opcion == "14":
            resultado = lista.filtrar_mayores_de_edad()
            resultado.listar()

        elif opcion == "15":
            print(lista.nombres_en_mayusculas())

        elif opcion == "C":
            cargar_datos(lista)

        elif opcion == "0":
            break

        else:
            print("Opción no válida.")

def main():
    while True:
        print("\n===== SISTEMA DE PASAJEROS =====")
        print("1. Lista manual")
        print("2. Lista Python")
        print("3. Ejercicios")
        print("4. Salir")

        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            menu_lista(lista1, "LISTA MANUAL")

        elif opcion == "2":
            menu_lista(lista2, "LISTA PYTHON")

        elif opcion == "3":
            menu_ejercicios()

        elif opcion == "4":
            print("Programa finalizado.")
            break

        else:
            print("Opción no válida.")


if __name__ == "__main__":
    main()