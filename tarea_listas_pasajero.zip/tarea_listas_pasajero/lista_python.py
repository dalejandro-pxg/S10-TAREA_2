from pasajero import Pasajero
from bisect import bisect_left


class ListaPasajerosPython:

    def __init__(self):
        self.pasajeros = []

    def añadir(self, pasajero):
        if self.buscar(pasajero.cedula) != -1:
            return False

        self.pasajeros.append(pasajero)
        return True

    def listar(self):
        if not self.pasajeros:
            print("Lista vacía")
            return

        for i, pasajero in enumerate(self.pasajeros):
            print(f"[{i}] {pasajero}")

    def longitud(self):
        return len(self.pasajeros)

    def insertar(self, posicion, pasajero):
        if posicion < 0 or posicion > len(self.pasajeros):
            return False

        if self.buscar(pasajero.cedula) != -1:
            return False

        self.pasajeros.insert(posicion, pasajero)
        return True

    def buscar(self, cedula):
        posiciones = [
            i for i, pasajero in enumerate(self.pasajeros)
            if pasajero.cedula == cedula
        ]

        if posiciones:
            return posiciones[0]

        return -1

    def buscar_binaria(self, cedula):
        cedulas = [p.cedula for p in self.pasajeros]

        if cedulas != sorted(cedulas):
            return -1

        posicion = bisect_left(cedulas, cedula)

        if posicion < len(cedulas) and cedulas[posicion] == cedula:
            return posicion

        return -1

    def modificar(self, cedula, nuevo_nombre, nueva_edad):
        posicion = self.buscar(cedula)

        if posicion == -1:
            return False

        self.pasajeros[posicion].nombre = nuevo_nombre
        self.pasajeros[posicion].edad = nueva_edad
        return True

    def eliminar_por_posicion(self, posicion):
        if posicion < 0 or posicion >= len(self.pasajeros):
            return None

        return self.pasajeros.pop(posicion)

    def eliminar_por_valor(self, cedula):
        cantidad_anterior = len(self.pasajeros)

        self.pasajeros = [
            p for p in self.pasajeros if p.cedula != cedula
        ]

        return len(self.pasajeros) < cantidad_anterior

    def ordenar_asc(self):
        self.pasajeros.sort(key=lambda p: p.cedula)

    def ordenar_desc(self):
        self.pasajeros.sort(key=lambda p: p.cedula, reverse=True)

    def reversar(self):
        self.pasajeros.reverse()

    def copiar(self):
        nueva_lista = ListaPasajerosPython()
        nueva_lista.pasajeros = self.pasajeros.copy()
        return nueva_lista

    def filtrar_mayores_de_edad(self):
        nueva_lista = ListaPasajerosPython()

        nueva_lista.pasajeros = [
            p for p in self.pasajeros if p.es_mayor_de_edad()
        ]

        return nueva_lista

    def nombres_en_mayusculas(self):
        return [
            p.nombre.upper() for p in self.pasajeros
        ]