def ejercicio_t1():
    print("\nT1 - Recorrido de pasajeros")

    nombres = ["Ana", "Luis", "Pedro", "María"]

    print("Solución manual:")
    for i in range(len(nombres)):
        print(nombres[i])

    print("Solución Python:")
    [print(nombre) for nombre in nombres]


def ejercicio_t2():
    print("\nT2 - Promedio de calificaciones")

    notas = [8, 9, 7, 10, 6]

    suma = 0
    for nota in notas:
        suma += nota

    promedio = suma / len(notas)
    print("Promedio manual:", promedio)

    promedio_python = sum(notas) / len(notas)
    print("Promedio Python:", promedio_python)


def ejercicio_t3():
    print("\nT3 - Ordenamiento de números")

    numeros = [8, 3, 5, 1, 9, 2]

    # Solución manual: método burbuja.
    manual = numeros.copy()

    for i in range(len(manual) - 1):
        for j in range(len(manual) - 1 - i):
            if manual[j] > manual[j + 1]:
                aux = manual[j]
                manual[j] = manual[j + 1]
                manual[j + 1] = aux

    print("Orden manual:", manual)

    # Solución Python.
    print("Orden Python:", sorted(numeros))

#Ejercicios propuestos
def propuesto_p1():
    print("\nP1 - Contar cuántas veces aparece un número")

    numeros = [2, 4, 2, 6, 2, 8]
    buscado = 2

    contador = 0
    for numero in numeros:
        if numero == buscado:
            contador += 1

    print("Conteo manual:", contador)
    print("Conteo Python:", numeros.count(buscado))


def propuesto_p2():
    print("\nP2 - Invertir una lista")

    numeros = [1, 2, 3, 4, 5]

    invertida = [None] * len(numeros)

    for i in range(len(numeros)):
        invertida[i] = numeros[len(numeros) - 1 - i]

    print("Inversión manual:", invertida)
    print("Inversión Python:", numeros[::-1])


def propuesto_p3():
    print("\nP3 - Eliminar números repetidos")

    numeros = [1, 2, 2, 3, 4, 3, 5]

    unicos = []

    for numero in numeros:
        if numero not in unicos:
            unicos.append(numero)

    print("Resultado manual:", unicos)
    print("Resultado Python:", list(dict.fromkeys(numeros)))


def propuesto_p4():
    print("\nP4 - Encontrar el segundo número mayor")

    numeros = [10, 5, 8, 20, 15, 20]

    mayor = None
    segundo = None

    for numero in numeros:
        if mayor is None or numero > mayor:
            segundo = mayor
            mayor = numero
        elif numero != mayor and (segundo is None or numero > segundo):
            segundo = numero

    print("Segundo mayor manual:", segundo)

    ordenados = sorted(set(numeros))
    print("Segundo mayor Python:", ordenados[-2])


def propuesto_p5():
    print("\nP5 - Unir dos listas ordenadas")

    lista_a = [1, 3, 5]
    lista_b = [2, 4, 6]

    resultado = []
    i = 0
    j = 0

    while i < len(lista_a) and j < len(lista_b):
        if lista_a[i] < lista_b[j]:
            resultado.append(lista_a[i])
            i += 1
        else:
            resultado.append(lista_b[j])
            j += 1

    while i < len(lista_a):
        resultado.append(lista_a[i])
        i += 1

    while j < len(lista_b):
        resultado.append(lista_b[j])
        j += 1

    print("Unión manual:", resultado)
    print("Unión Python:", sorted(lista_a + lista_b))


def menu_ejercicios():
    ejercicios = {
        "1": ejercicio_t1,
        "2": ejercicio_t2,
        "3": ejercicio_t3,
        "4": propuesto_p1,
        "5": propuesto_p2,
        "6": propuesto_p3,
        "7": propuesto_p4,
        "8": propuesto_p5
    }

    while True:
        print("\n===== MENÚ DE EJERCICIOS =====")

        # Comprensión para mostrar las opciones del menú.
        [print(f"{numero}. {funcion.__name__}")
         for numero, funcion in ejercicios.items()]

        print("0. Volver")

        opcion = input("Seleccione: ").strip()

        if opcion == "0":
            break

        if opcion in ejercicios:
            ejercicios[opcion]()
        else:
            print("Opción no válida.")